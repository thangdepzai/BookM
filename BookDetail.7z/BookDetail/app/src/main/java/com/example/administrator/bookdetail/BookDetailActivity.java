package com.example.administrator.bookdetail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class BookDetailActivity extends AppCompatActivity implements View.OnClickListener{

    private static final int REQUEST_CODE = 41;
    Button mBtnChangeInfo, mBtnSaveInfo, mBtnRead;
    TextView mTvBookName, mTvAuthor, mTvCategory, mTvDescription;
    Spinner mSpCategory;
    EditText mEdBookName, mEdAuthor, mEdDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        mBtnRead = findViewById(R.id.btn_read);
        mBtnChangeInfo = (Button) findViewById(R.id.btn_change_info);
        mTvBookName = findViewById(R.id.tv_book_name);
        mTvAuthor = findViewById(R.id.tv_author);
        mTvCategory = findViewById(R.id.tv_category);
        mTvDescription = findViewById(R.id.tv_description);

        mBtnSaveInfo = findViewById(R.id.btn_save_info);
        mEdBookName = findViewById(R.id.ed_book_name);
        mEdAuthor = findViewById(R.id.ed_author);
        mSpCategory = findViewById(R.id.sp_category);
        mEdDescription = findViewById(R.id.ed_description);

        mBtnSaveInfo.setVisibility(View.GONE);
        mEdBookName.setVisibility(View.GONE);
        mEdAuthor.setVisibility(View.GONE);
        mSpCategory.setVisibility(View.GONE);
        mEdDescription.setVisibility(View.GONE);

        mBtnChangeInfo.setOnClickListener(this);
        mBtnSaveInfo.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_change_info:

                mBtnSaveInfo.setVisibility(View.VISIBLE);
                mEdBookName.setVisibility(View.VISIBLE);
                mEdBookName.setText(mTvBookName.getText().toString());
                mEdAuthor.setVisibility(View.VISIBLE);
                mEdAuthor.setText(mTvAuthor.getText().toString());
                mSpCategory.setVisibility(View.VISIBLE);
                mEdDescription.setVisibility(View.VISIBLE);
                mEdDescription.setText(mTvDescription.getText().toString());

                mBtnChangeInfo.setVisibility(View.GONE);
                mTvBookName.setVisibility(View.GONE);
                mTvAuthor.setVisibility(View.GONE);
                mTvCategory.setVisibility(View.GONE);
                mTvDescription.setVisibility(View.GONE);
                mBtnRead.setVisibility(View.INVISIBLE);

                break;
            case R.id.btn_save_info:

                mBtnChangeInfo.setVisibility(View.VISIBLE);
                mTvBookName.setVisibility(View.VISIBLE);
                mTvBookName.setText(mEdBookName.getText().toString());
                mTvAuthor.setVisibility(View.VISIBLE);
                mTvAuthor.setText(mEdAuthor.getText().toString());
                mTvCategory.setVisibility(View.VISIBLE);
                mTvDescription.setVisibility(View.VISIBLE);
                mTvDescription.setText(mEdDescription.getText().toString());

                mBtnSaveInfo.setVisibility(View.GONE);
                mEdBookName.setVisibility(View.GONE);
                mEdAuthor.setVisibility(View.GONE);
                mSpCategory.setVisibility(View.GONE);
                mEdDescription.setVisibility(View.GONE);
                mBtnRead.setVisibility(View.VISIBLE);

                break;
        }
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data){
//        if(requestCode == 41){
//            mTvBookName.setText(data.getStringExtra("book_name"));
//            mTvAuthor.setText(data.getStringExtra( "author"));
//        }
//    }

}
